rm out/*
rm out/airfoils/*
rm out/stats/*
rm out/tmp/*
