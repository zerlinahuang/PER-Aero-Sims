import sys
import os.path as op
path = op.dirname(op.dirname(op.dirname(op.abspath(__file__))))
print('Setting project root path: ' + path)
sys.path.append(path)

import numpy as np

from airsim import sim
from airsim import presets
from airsim import dirs
from airsim from mesh import MeshScheme
from airsim.airfoil import Airfoil,AirfoilElement

x_values = np.linspace(-15, -6, 10)
y_values = np.linspace(-10, 10, 21)
chor_values = np.linspace(5, 13, 81)
rot_values = np.linspace(-20, -0, 21)
max_iterations = 5
precision = .0000000001
iterations = 1
acc = 999
prev_downforce = 999
cur_downforce = 0
x = -8
y = 0
chord = 0.076
rot = -12

# The s1223 airfoil shape; good for high downforce and low reynolds #s
s1223 = np.loadtxt(open(dirs.res_path("s1223.txt"), "rb"))
s1223 = np.flipud(s1223)
# Cut of trailing edge (causes meshing issues)
s1223 = s1223[2:-2,:]
# If you want to subsample the airfoil
#_s1223 = _s1223[::5]

# A basic symmetric airfoil
airfoil_elems = [AirfoilElement(s1223, [float(x)/100.0, float(y)/100.0], chord,  rot),
                 AirfoilElement(s1223, [0, 0], 0.457,  8)];
airfoil_test_combination = Airfoil(airfoil_elems)

def run_sim(combo):
    simOut = sim.analyze_airfoil(combo,
            presets.fine_lead_mesh_scheme(combo))
    return float(simOut["lift"]) 

f = open("src/gd_out.txt", "w")
cur_downforce = run_sim(airfoil_test_combination)
f.write(str(0) + " " + str(cur_downforce) + " " + str(acc) + " " + str(x) + " " + str(y) + " " + str(chord) + " " + str(rot) + "\n")
while (iterations <= max_iterations and acc > precision):
    try:
        df_options = []
        if (np.any(x_values == (x + 1))):
            airfoil_test_combination.elems[0].pos = [float(x + 1)/100.0, float(y)/100.0]
            x_inc = run_sim(airfoil_test_combination)
            df_options.append(x_inc)
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
        else:
            df_options.append(cur_downforce)
        if (np.any(x_values == (x - 1))):
            airfoil_test_combination.elems[0].pos = [float(x - 1)/100.0, float(y)/100.0]
            x_dec = run_sim(airfoil_test_combination)
            df_options.append(x_dec)
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
        else:
            df_options.append(cur_downforce)
        if (np.any(y_values == (y + 1))):
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y + 1)/100.0]
            y_inc = run_sim(airfoil_test_combination)
            df_options.append(y_inc)
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
        else:
            df_options.append(cur_downforce)
        if (np.any(y_values == (y - 1))):
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y - 1)/100.0]
            y_dec = run_sim(airfoil_test_combination)
            df_options.append(y_dec)
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
        else:
            df_options.append(cur_downforce)
        sorted_options = np.sort(df_options)
        max_df = 0
        for i in range(len(sorted_options)):
            if sorted_options[i] < 10:
                max_df = sorted_options[i]
                break
        idx_md, = np.where(df_options==max_df)
        idx_md = int(idx_md)
        if idx_md == 0:
            airfoil_test_combination.elems[0].pos = [float(x + 1)/100.0, float(y)/100.0]
            x = x + 1
        if idx_md == 1:
            airfoil_test_combination.elems[0].pos = [float(x - 1)/100.0, float(y)/100.0]
            x = x - 1
        if idx_md == 2:
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y + 1)/100.0]
            y = y + 1
        if idx_md == 3:
            airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y - 1)/100.0]
            y = y - 1
        acc = abs((df_options[idx_md] - cur_downforce)/cur_downforce)
        cur_downforce = df_options[idx_md]
        f.write(str(iterations) + " " + str(cur_downforce) + " " + str(acc) + " " + str(x) + " " + str(y) + " " + str(chord) + " " + str(rot) + "\n")    
        iterations = iterations + 1
        print(iterations)
    except IOError:
        print('An error occured trying to read the file.')
    except RuntimeError:
        print('RUNTIME ERROR')
    
