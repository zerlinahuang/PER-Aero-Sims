import sys
import os.path as op
path = op.dirname(op.dirname(op.dirname(op.abspath(__file__))))
print('Setting project root path: ' + path)
sys.path.append(path)

import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter

x = []
y = []
z = []

with open("src/out/5elem_xy_chord_7.6_theta_-12_points_441.txt", "r") as ins:
    for line in ins:
        vals = line.split(",")
        if float(vals[2]) < 0 and float(vals[2]) > -100:  
            x.append(float(vals[0]))
            y.append(float(vals[1]))
            z.append(float(vals[2]))
        
z = np.array(z)
x = np.array(x)
y = np.array(y)
print(x)
print(y)
print(z)
max_d = np.amin(z)
idx_z, = np.where(z==max_d)
print("The max downforce of: " + str(max_d) + " is at x: " + str(x[idx_z]) + " and y: " + str(y[idx_z]))

fig = plt.figure()

ax = fig.gca(projection='3d')
ax.plot_trisurf(x, y, z, cmap=plt.cm.viridis, linewidth=0.2)
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('DownForce')
plt.show()
