import sys
import os.path as op
path = op.dirname(op.dirname(op.dirname(op.abspath(__file__))))
print('Setting project root path: ' + path)
sys.path.append(path)

from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np

from airsim import sim
from airsim import presets
from airsim import dirs
from airsim.airfoil import Airfoil,AirfoilElement
from airsim.mesh import MeshScheme

# The s1223 airfoil shape; good for high downforce and low reynolds #s
s1223 = np.loadtxt(open(dirs.res_path("s1223.txt"), "rb"))
s1223 = np.flipud(s1223)
# Cut of trailing edge (causes meshing issues)
s1223 = s1223[2:-2,:]
# If you want to subsample the airfoil
#_s1223 = _s1223[::5]

# A basic symmetric airfoil
airfoil_elems = [AirfoilElement(s1223, [-0.14, 0],     0.076,  -12),
                 AirfoilElement(s1223, [0,     0],     0.457,  8)]


airfoil_test_combination = Airfoil(airfoil_elems)

pos_results = []

x_vals = np.linspace(-20,0, 21)
y_vals = np.linspace(-10,10, 21)
print(x_vals)
print(y_vals)
points = len(x_vals) * len(y_vals)

f = open("src/out/2elem,xy,chord_7.6,theta_-12,points_" + str(points) + ".txt", "w")
#Tests all combinations
# for x in range(-13, -6, 1):
#     for y in range(-12, 1, 1):
#         try:
#                 x_val.append(x)
#                 y_val.append(y)
#                 airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
#                 simOut = sim.analyze_airfoil(airfoil_test_combination,
#                      presets.fine_lead_mesh_scheme(airfoil_test_combination))
#                 pos_results.append(simOut["lift"])  

#                 f.write(str(x) + ", " + str(y) + ", " + str(simOut["lift"]) + "\n") 
#         except IOError, RuntimeError:
#                 print('An error occured trying to read the file.')

for x in x_vals:
    for y in y_vals:
        try:
                airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
                simOut = sim.analyze_airfoil(airfoil_test_combination,
                     presets.fine_lead_mesh_scheme(airfoil_test_combination))

                f.write(str(x) + ", " + str(y) + ", " + str(simOut["lift"]) + "\n") 
        except IOError:
                print('An error occured trying to read the file.')
        except RuntimeError:
                print("An error occured")
        

f.close()


   

# factor_results = []
# for alpha in range(-20, 0, 10):
#     for chord_length in range(5, 13, 4):
#         airfoil_test_combination.elems[0].chord = chord_length
#         airfoil_test_combination.elems[0].rot = alpha
#         simOut = sim.analyze_airfoil(airfoil_test_combination,
#                      presets.fine_lead_mesh_scheme(airfoil_test_combination))
#         factor_results.append(simOut[0])
