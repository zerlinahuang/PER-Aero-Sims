import sys
import os.path as op
path = op.dirname(op.dirname(op.dirname(op.abspath(__file__))))
print('Setting project root path: ' + path)
sys.path.append(path)

import csv
import numpy as np

from airsim import sim
from airsim import presets
from airsim import dirs
from airsim.airfoil import Airfoil,AirfoilElement
from airsim.mesh import MeshScheme

# The s1223 airfoil shape; good for high downforce and low reynolds #s
s1223 = np.loadtxt(open(dirs.res_path("s1223.txt"), "rb"))
s1223 = np.flipud(s1223)
# Cut of trailing edge (causes meshing issues)
s1223 = s1223[2:-2,:]
# If you want to subsample the airfoil
#_s1223 = _s1223[::5]

# A basic symmetric airfoil
airfoil_elems = [AirfoilElement(s1223, [-0.14, 0],     0.076,  -12),
                 AirfoilElement(s1223, [0,     0],     0.457,  8),
                 AirfoilElement(s1223, [0.43,  0.09],  0.191,  30),
                 AirfoilElement(s1223, [0.59,  0.20],  0.114,  52),
                 AirfoilElement(s1223, [0.65,  0.30],  0.076,  60)]


airfoil_test_combination = Airfoil(airfoil_elems)

x_vals = np.linspace(-20,-16, 3)
y_vals = np.linspace(-9, -5, 3)
chord_vals = np.linspace(12.5 ,15, 3)
theta_vals = np.linspace(-13,-9, 5)
points = len(x_vals) * len(y_vals) * len(chord_vals) * len(theta_vals)

#Tests all combinations
# for x in range(-13, -6, 1):
#     for y in range(-12, 1, 1):
#         try:
#                 x_val.append(x)
#                 y_val.append(y)
#                 airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
#                 simOut = sim.analyze_airfoil(airfoil_test_combination,
#                      presets.fine_lead_mesh_scheme(airfoil_test_combination))
#                 pos_results.append(simOut["lift"])  

#                 f.write(str(x) + ", " + str(y) + ", " + str(simOut["lift"]) + "\n") 
#         except IOError, RuntimeError:
#                 print('An error occured trying to read the file.')
i = 1
for x in x_vals:
    for y in y_vals:
        for chord in chord_vals:
                for theta in theta_vals:
                        try:
                                airfoil_test_combination.elems[0].pos = [float(x)/100.0, float(y)/100.0]
                                airfoil_test_combination.elems[0].chord = float(chord)/100.0
                                airfoil_test_combination.elems[0].rot = theta
                                simOut = sim.analyze_airfoil(airfoil_test_combination,
                                presets.fine_lead_mesh_scheme(airfoil_test_combination))
                                with open('src/out/downforces_narrow.csv', mode='a') as df:
                                        df_writer = csv.writer(df, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                                        df_writer.writerow([str(x), str(y), str(chord), str(theta), str(simOut["lift"])])
                                print(str(i) + " out of " + str(points) + " trials.")
                                i = i + 1
                        except IOError:
                                print('An error occured trying to read the file.')
                        except RuntimeError:
                                print("An error occured")
        



   

# factor_results = []
# for alpha in range(-20, 0, 10):
#     for chord_length in range(5, 13, 4):
#         airfoil_test_combination.elems[0].chord = chord_length
#         airfoil_test_combination.elems[0].rot = alpha
#         simOut = sim.analyze_airfoil(airfoil_test_combination,
#                      presets.fine_lead_mesh_scheme(airfoil_test_combination))
#         factor_results.append(simOut[0])
