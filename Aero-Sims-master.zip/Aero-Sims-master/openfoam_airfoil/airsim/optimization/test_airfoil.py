from colorama import init

from airsim import sim
from airsim import presets
from airsim.airfoil import Airfoil, AirfoilElement

import gene_utils as genes

# Initialize terminal colors
init()
individual = [0, 0, -35, 0.076, 0.019463531796124273, 0.03862863376803804, 9.999958994776986, 0.457, -0.0199699587704261, 0.02386202240015542, 45.769911738206915, 0.191, -0.004748877402676904, 0.02841247407761386, 64.20443201225311, 0.114, -0.003615101517980012, 0.0102, 80, 0.076]

airfoil = genes.to_airfoil(individual)
airfoil.set_profile_coords(presets.s1223)

try:
    simOut = sim.analyze_airfoil(airfoil,
                 presets.fine_lead_mesh_scheme(airfoil))
except ValueError as e:
    print(e)
