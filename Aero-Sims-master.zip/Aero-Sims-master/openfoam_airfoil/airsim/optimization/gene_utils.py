import math
import copy
from random import uniform
import operator
import numpy

from airsim.airfoil import Airfoil, AirfoilElement

class Constraint:
    def __init__(self):
        self.dx = [float("-inf"), float("inf")]
        self.dy = [float("-inf"), float("inf")]
        self.rot = [float("-inf"), float("inf")]
        self.chord = [float("-inf"), float("inf")]

    def wdx(self, min_dx, max_dx):
        self.dx = [min_dx, max_dx]
        return self

    def wdy(self, min_dy, max_dy):
        self.dy = [min_dy, max_dy]
        return self

    def wrot(self, min_rot, max_rot):
        self.rot = [min_rot, max_rot]
        return self

    def wchord(self, min_chord, max_chord):
        self.chord = [min_chord, max_chord]
        return self

def clamp(n, smallest, largest):
    return max(smallest, min(n, largest))

def add(v1, v2):
    return list(map(operator.add, v1, v2))

def elem_struct(leading_pos, trailing_pos, delta_pos, rot, chord):
    return { "leading_pos": leading_pos, "trailing_pos": trailing_pos,
             "delta_pos": delta_pos, "rot": rot, "chord": chord }

def parse(genes, handle_parse):
    genes = genes[:]
    
    # Coordinates of last element's trailing edge
    trailing_pos = [0, 0]
    for i in range(0, len(genes), 4):
        delta_pos = [genes[i], genes[i + 1]]
        rot = genes[i + 2]
        chord = genes[i + 3]

        rot_standard = math.radians(rot)
        
        leading_pos = add(trailing_pos, delta_pos)

        trailing_pos = add(leading_pos, [math.cos(rot_standard) * chord,
                                         math.sin(rot_standard) * chord])

        returned = handle_parse(elem_struct(leading_pos, trailing_pos,
                                delta_pos, rot, chord), i // 4)
        if returned is not None:
            genes[i] = returned["delta_pos"][0]
            genes[i + 1] = returned["delta_pos"][1]
            genes[i + 2] = returned["rot"]
            genes[i + 3] = returned["chord"]
    
    return genes

def genes_equal(genes1, genes2):
    return numpy.allclose(genes1, genes2)

def jiggle(genes):
    def jiggle_elem(elem, _):
        dp = 0.0005 
        dr = 0.1
        elem["delta_pos"] = add(elem["delta_pos"],
            [uniform(-dp, dp), uniform(-dp, dp)])
        elem["rot"] = elem["rot"] + uniform(-dr, dr)
        return elem
    return parse(genes, jiggle_elem)

def overall_size(genes):
    # min_x, max_x, min_y, max_y
    bounds = [float("inf"), -float("inf"), float("inf"), -float("inf")]
    def size_update(elem, i):
        lp, tp = elem["leading_pos"], elem["trailing_pos"]
        bounds[0] = min(bounds[0], lp[0], tp[0])
        bounds[1] = max(bounds[1], lp[0], tp[0])

        bounds[2] = min(bounds[2], lp[1], tp[1])
        bounds[3] = max(bounds[3], lp[1], tp[1])
    parse(genes, size_update)

    return bounds[1] - bounds[0], bounds[3] - bounds[2] 

def constrain_elems(genes, elem_constraints):
    def constrain_elem(elem, i):
        elem["delta_pos"][0] = clamp(elem["delta_pos"][0],
                                     elem_constraints[i].dx[0],
                                     elem_constraints[i].dx[1])
        elem["delta_pos"][1] = clamp(elem["delta_pos"][1],
                                     elem_constraints[i].dy[0],
                                     elem_constraints[i].dy[1])
        elem["rot"] = clamp(elem["rot"],
                            elem_constraints[i].rot[0],
                            elem_constraints[i].rot[1])
        elem["chord"] = clamp(elem["chord"],
                              elem_constraints[i].chord[0],
                              elem_constraints[i].chord[1])
        return elem

    return parse(genes, constrain_elem)

def constrain(genes, constraints):
    genes = constrain_elems(genes, constraints["elem_constraints"])
    return genes

def constrained_random(constraints):
    genes = []
    elem_constraints = constraints["elem_constraints"]
    for i, constraint in enumerate(elem_constraints):
        genes.append(uniform(constraint.dx[0], constraint.dx[1]))
        genes.append(uniform(constraint.dy[0], constraint.dy[1]))
        genes.append(uniform(constraint.rot[0], constraint.rot[1]))
        genes.append(uniform(constraint.chord[0], constraint.chord[1]))

    return genes

def to_airfoil(genes):
    elems = []
    def convert_elem(elem, i):
        elems.append(AirfoilElement(
            elem["leading_pos"],
            elem["rot"],
            elem["chord"]))
    parse(genes, convert_elem)

    return Airfoil(elems)

def to_string(genes):
    s = {"string": ""}
    def elem_to_string(elem, i):
        string = s["string"]
        string = string + "Elem " + str(i) + " x overlap: " + str(elem["delta_pos"][0]) + "\n"
        string = string + "Elem " + str(i) + " y gap: " + str(elem["delta_pos"][1]) + "\n"
        string = string + "Elem " + str(i) + " rot: " + str(elem["rot"]) + "\n"
        string = string + "Elem " + str(i) + " chord: " + str(elem["chord"]) + "\n"
        s["string"] = string

    parse(genes, elem_to_string)
    return s["string"]
