// Standalone script, run with node
const D3Node = require('d3-node');
const d3 = require('d3');
const fs = require('fs');
const xmljs = require('xml-js');
const program = require('commander');
const path = require('path');
 
program
  .option('-h, --history', 'Render evolution history')
  .option('-f, --fitness', 'Render fitness')
  .parse(process.argv);

var options = {
    d3Module: d3
};

var d3n = new D3Node(options);

var margin = {top: 30, right: 30, bottom: 50, left: 30},
    width = 900 - margin.left - margin.right,
    height = 900 - margin.top - margin.bottom,
    minX = -0.5, minY = -0.5,
    maxX = 2, maxY = 2;

var xValue = function(d) { return d[0];},
    xScale = d3.scaleLinear().domain([minX,maxX]).range([0, width]),
    xMap = function(d) { return xScale(xValue(d));},
    xAxis = d3.axisBottom(xScale);

var yValue = function(d) { return d[1];},
    yScale = d3.scaleLinear().domain([minY,maxY]).range([height, 0]),
    yMap = function(d) { return yScale(yValue(d));},
    yAxis = d3.axisLeft(yScale);

var color = d3.scaleOrdinal(d3.schemeCategory10);

var svg = d3n.createSVG(width + margin.left + margin.right,
                        height + margin.top + margin.bottom).append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

svg.append("g")
    .attr("class", "x axis")
    .attr("transform", "translate(0," + height + ")")
    .call(xAxis);

svg.append("g")
    .attr("class", "y axis")
    .call(yAxis);


var rootPath = function(p) {
    return path.resolve(__dirname, "../" + p);
}

var genCount = fs.readdirSync(rootPath("out/airfoils")).length;

var readAirfoil = function(filename) {
    var content = fs.readFileSync(filename, 'utf8');

    var converted = xmljs.xml2json(content, {compact: true, spaces: 4,
                    nativeType: true, nativeTypeAttributes: true});

    var json = JSON.parse(converted);
    var elements = json.airfoil.elements.element;

    // If just one element, put it in a list to help keep the later processing consistent
    if (elements.length == undefined) {
        elements = [elements];
    }

    var airfoil = [];
    for (var i = 0; i < elements.length; i++) {
        var element = elements[i];
        var points = element.coordinates.point;
        var pointsOut = [];
        for (var j = 0; j < points.length; j++) {
            var point = points[j];
            var x = point.x._text;
            var y = point.y._text;
            pointsOut.push([x,y]);
        }
        airfoil.push(pointsOut);
    }
    return airfoil;
}

var renderAirfoil = function(airfoil, opacity, outline) {
    for (var elem = 0; elem < airfoil.length; elem++) {
        var polyDraw = function() {
            var poly = svg.selectAll(".polygon" + gen + "-" + elem);

            return poly.data([airfoil[elem]])
                .enter().append("polygon")
                .attr("points",function(d) { 
                     return d.map(function(d) { return [xMap(d),yMap(d)].join(","); }).join(" ");
                 })
        }

        if (outline) {
            polyDraw().attr("fill", "none")
                .attr("stroke", "black")
                .attr("stroke-width",2)
                .style("opacity", opacity);
        }

        polyDraw().attr("fill", "none")
            .attr("stroke",color(elem))
            .attr("stroke-width",1)
            .style("opacity", opacity);
    }
}

// If we want to render the evolution history, sample old genes and render them transparent
if (program.history) {
    var genSkip = Math.ceil(genCount / 40);
    for (var gen = 1; gen < genCount - 1; gen += genSkip) {
        airfoil = readAirfoil(rootPath("out/airfoils/airfoil" + gen + ".xml"));
        var opacity = 0.05 + 0.15 * gen / genCount;

        renderAirfoil(airfoil, opacity, false);
    }
}

// Always render the last generation with full transparency and an outline
var lastGen = genCount;
var airfoil = readAirfoil(rootPath("out/airfoils/airfoil" + lastGen + ".xml"));
renderAirfoil(airfoil, 1, true);

if (program.fitness) {
    // Make mini fitness graph
    var fitness = [];
    for (var gen = 1; gen <= genCount; gen++) {
        var genStr = fs.readFileSync(rootPath("out/stats/stat" + gen + ".txt"));
        fitness.push({gen: gen-1, fitness: JSON.parse(genStr).fitness});
    }
    
    var miniWidth = 300,
        miniHeight = 300,
        miniX = 50,
        miniY = 30,
        maxFitness = Math.max(...fitness.map(x => x.fitness));
    
    var roundDecimal = 1;
    var fitVal = maxFitness;
    while (fitVal > 1) {
        fitVal = fitVal / 10;
        roundDecimal = roundDecimal * 10;
    }
    maxFitness = Math.ceil(maxFitness / 10) * 10;

    var genValue = function(d) { return d.gen; },
        genScale = d3.scaleLinear().domain([0,genCount-1]).range([0, miniHeight]),
        genMap   = function(d) { return genScale(genValue(d));},
        genAxis  = d3.axisBottom(genScale);

    var fitnessValue    = function(d) { return d.fitness; },
        fitnessScale    = d3.scaleLinear().domain([0, maxFitness]).range([miniWidth, 0]),
        fitnessMap      = function(d) { return fitnessScale(fitnessValue(d)); },
        fitnessAxis     = d3.axisLeft(fitnessScale);

    var line = d3.line().x(function(d) { return genMap(d); })
                        .y(function(d) { return fitnessMap(d); });

    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(" + miniX + ", " + (miniY + miniHeight) + ")")
        .call(genAxis);
    svg.append("g")
        .attr("class", "y axis")
        .attr("transform", "translate(" + miniX + ", " + miniY + ")")
        .call(fitnessAxis);

    svg.append("g").append("path")
       .datum(fitness)
       .attr("fill", "none")
       .attr("stroke", "black")
       .attr("stroke-linejoin", "round")
       .attr("stroke-linecap", "round")
       .attr("stroke-width", 1.5)
       .attr("class", "line")
       .attr("transform", "translate(" + miniX + ", " + miniY + ")")
       .attr("d", line);

    svg.append("g").selectAll("text")
                   .data([fitness[fitness.length - 1]])
                   .enter()
                   .append("text")
                   .attr("transform", "translate(" + (miniX + 10) + ", " + (miniY + 10) + ")")
                   .attr("text-anchor", "start")
                   .attr("x", function(d) { return genMap(d); })
                   .attr("y", function(d) { return fitnessMap(d); })
                   .text(function(d) { return d.fitness.toFixed(2); });

    svg.append("text").attr("x", miniX)
                      .attr("y", miniY - 15)
                      .style("text-anchor", "middle")
                      .text("fitness");

    svg.append("text").attr("x", miniX + miniWidth + 5)
                      .attr("y", miniY  + miniHeight + 5)
                      .style("text-anchor", "start")
                      .text("gen");
}

fs.writeFile(rootPath("out/airfoil.svg"), d3n.svgString()); 
